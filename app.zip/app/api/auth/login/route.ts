// app/api/auth/login/route.ts
import { NextResponse } from 'next/server';
import { neon } from '@neondatabase/serverless';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const sql = neon(process.env.DATABASE_URL as string);

// ******* VALIDACIÓN CRÍTICA DE JWT_SECRET *******
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('JWT_SECRET no está definido en las variables de entorno. Por favor, configúralo en .env.local y en Vercel.');
}
// *************************************************

interface Body {
  email: string;
  password: string;
}

export async function POST(request: Request) {
  try {
    const { email, password }: Body = await request.json();

    if (!email || !password) {
      return NextResponse.json({ message: 'Faltan email o contraseña' }, { status: 400 });
    }

    // 1) Buscar el usuario por email
    const rows = await sql`
      SELECT id, email, password_hash, role, nombre, apellidos, tratamiento
      FROM usuarios
      WHERE email = ${email}
    `;

    if (rows.length === 0) {
      return NextResponse.json({ message: 'Credenciales inválidas' }, { status: 401 });
    }

    const user = rows[0];

    // 2) Función para limpiar posibles errores de codificación
    function limpiarTexto(texto: any) {
      return texto ? texto.toString() : '';
    }

    const nombre = limpiarTexto(user.nombre);
    const apellidos = limpiarTexto(user.apellidos);
    const tratamiento = limpiarTexto(user.tratamiento);

    // 3) Comparar la contraseña con el hash
    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      return NextResponse.json({ message: 'Credenciales inválidas' }, { status: 401 });
    }

    // 4) Crear token JWT con los datos del usuario
    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        nombre,
        apellidos,
        tratamiento,
        role: user.role,
      },
      JWT_SECRET!, // <--- ¡CAMBIO AQUÍ! Añadimos '!' para asegurar a TypeScript que no es undefined
      { expiresIn: '7d' }
    );

    // 5) Devolver usuario y token
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        nombre,
        apellidos,
        tratamiento,
      },
      token,
    });

  } catch (err) {
    console.error('Error en /api/auth/login:', err);
    return NextResponse.json({ message: 'Error interno' }, { status: 500 });
  }
}
